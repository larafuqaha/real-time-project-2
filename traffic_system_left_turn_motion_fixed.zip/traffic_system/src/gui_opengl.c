/*****************************************************************************
 *  gui_opengl.c
 *  ---------------------------------------------------------------------------
 *  Realistic OpenGL visualisation of the intersection.
 *
 *  - Top-down/perspective view of a 4-way intersection.
 *  - Asphalt roads with lane markings and pedestrian zebra crossings.
 *  - 3-D traffic-light poles at each corner with red/yellow/green lamps that
 *    actually glow when active.
 *  - Cars are simple 3-D boxes that appear in lanes when vehicles are
 *    detected in shared memory and move during their green phase.
 *  - Pedestrians (small standing figures) appear on sidewalks and walk across
 *    when the pedestrian phase is active.
 *  - Emergency vehicle: a red car with flashing blue/red lights when active.
 *  - HUD overlay showing the current phase, countdown, queue lengths.
 *
 *  Dependencies: freeglut (libglut), GLU, GL.
 *  Build:        see Makefile (uses pkg-config or -lglut -lGLU -lGL).
 *
 *  The GUI is a pure consumer of the shared state — it never modifies it,
 *  so it doesn't need to hold the mutex for long; it takes a snapshot,
 *  releases the lock, then renders.
 *****************************************************************************/
#include "common.h"
#include "ipc_init.h"

#include <GL/glut.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* IPC */
static int            shmid = -1, semid = -1, qevt = -1, qlog = -1;
static shared_state_t *S = NULL;
static shared_state_t  snap;        /* local snapshot per frame    */

/* window */
static int   WIN_W = 1100, WIN_H = 760;
static float cam_angle   = 25.0f;      /* tilt above horizon */
static float cam_rotate  = 0.0f;       /* rotate around y    */
static float cam_dist    = 28.0f;
static int   show_help   = 1;

/* recent events ring buffer for HUD display */
#define MAX_RECENT_EVENTS 5
static char recent_events[MAX_RECENT_EVENTS][128];
static int  recent_count = 0;
static int  recent_head  = 0;

/* animation */
static float t_animation = 0.0f;       /* global anim time   */

/* ---------- low-level draw helpers ---------------------------------- */

static void set_color(float r, float g, float b)
{
    GLfloat m[] = {r, g, b, 1.0f};
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, m);
    glColor3f(r, g, b);
}

static void set_emissive(float r, float g, float b)
{
    GLfloat e[] = {r, g, b, 1.0f};
    glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, e);
}
static void clear_emissive(void)
{
    GLfloat e[] = {0, 0, 0, 1};
    glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, e);
}

/* draw an axis-aligned cuboid centred at origin with given size */
static void draw_box(float sx, float sy, float sz)
{
    glPushMatrix();
    glScalef(sx, sy, sz);
    glutSolidCube(1.0f);
    glPopMatrix();
}

static void draw_text(float x, float y, const char *s)
{
    glRasterPos2f(x, y);
    while (*s) glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *s++);
}

static void draw_text_big(float x, float y, const char *s)
{
    glRasterPos2f(x, y);
    while (*s) glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *s++);
}

/* ---------- world drawing -------------------------------------------- */

#define ROAD_HALF_WIDTH   4.4f   /* 4-lane road: 2 lanes each way */
#define ROAD_LENGTH       18.0f
#define INTER_HALF        4.4f   /* wider realistic intersection */

static void draw_ground(void)
{
    /* big grass plane */
    set_color(0.18f, 0.42f, 0.18f);
    glBegin(GL_QUADS);
        glNormal3f(0, 1, 0);
        glVertex3f(-25, 0, -25);
        glVertex3f( 25, 0, -25);
        glVertex3f( 25, 0,  25);
        glVertex3f(-25, 0,  25);
    glEnd();

    /* sidewalks (lighter quads around corners) */
    set_color(0.65f, 0.65f, 0.62f);
    for (int dx = -1; dx <= 1; dx += 2)
    for (int dz = -1; dz <= 1; dz += 2) {
        float x0 = dx * ROAD_HALF_WIDTH;
        float x1 = dx * (ROAD_HALF_WIDTH + 3.0f);
        float z0 = dz * ROAD_HALF_WIDTH;
        float z1 = dz * (ROAD_HALF_WIDTH + 3.0f);
        glBegin(GL_QUADS);
        glNormal3f(0, 1, 0);
        glVertex3f(x0, 0.02f, z0);
        glVertex3f(x1, 0.02f, z0);
        glVertex3f(x1, 0.02f, z1);
        glVertex3f(x0, 0.02f, z1);
        glEnd();
    }
}

static void draw_roads(void)
{
    /* asphalt */
    set_color(0.16f, 0.16f, 0.18f);

    /* horizontal road (East-West) */
    glBegin(GL_QUADS);
    glNormal3f(0, 1, 0);
    glVertex3f(-ROAD_LENGTH, 0.03f, -ROAD_HALF_WIDTH);
    glVertex3f( ROAD_LENGTH, 0.03f, -ROAD_HALF_WIDTH);
    glVertex3f( ROAD_LENGTH, 0.03f,  ROAD_HALF_WIDTH);
    glVertex3f(-ROAD_LENGTH, 0.03f,  ROAD_HALF_WIDTH);
    glEnd();

    /* vertical road (North-South) */
    glBegin(GL_QUADS);
    glNormal3f(0, 1, 0);
    glVertex3f(-ROAD_HALF_WIDTH, 0.03f, -ROAD_LENGTH);
    glVertex3f( ROAD_HALF_WIDTH, 0.03f, -ROAD_LENGTH);
    glVertex3f( ROAD_HALF_WIDTH, 0.03f,  ROAD_LENGTH);
    glVertex3f(-ROAD_HALF_WIDTH, 0.03f,  ROAD_LENGTH);
    glEnd();

    /* lane dividers (dashed yellow lines) */
    set_color(0.95f, 0.85f, 0.15f);
    /* east-west centre dashes */
    for (float x = -ROAD_LENGTH; x < ROAD_LENGTH; x += 1.5f) {
        if (fabsf(x) < INTER_HALF) continue;
        glBegin(GL_QUADS);
        glNormal3f(0, 1, 0);
        glVertex3f(x,      0.05f, -0.08f);
        glVertex3f(x+0.8f, 0.05f, -0.08f);
        glVertex3f(x+0.8f, 0.05f,  0.08f);
        glVertex3f(x,      0.05f,  0.08f);
        glEnd();
    }
    /* north-south centre dashes */
    for (float z = -ROAD_LENGTH; z < ROAD_LENGTH; z += 1.5f) {
        if (fabsf(z) < INTER_HALF) continue;
        glBegin(GL_QUADS);
        glNormal3f(0, 1, 0);
        glVertex3f(-0.08f, 0.05f, z);
        glVertex3f( 0.08f, 0.05f, z);
        glVertex3f( 0.08f, 0.05f, z+0.8f);
        glVertex3f(-0.08f, 0.05f, z+0.8f);
        glEnd();
    }

    /* white dashed lane separators: each road has 4 sections (2 lanes each way) */
    set_color(0.88f, 0.88f, 0.88f);
    for (float x = -ROAD_LENGTH; x < ROAD_LENGTH; x += 1.4f) {
        if (fabsf(x) < INTER_HALF) continue;
        for (int side = -1; side <= 1; side += 2) {
            float z = side * 2.2f;
            glBegin(GL_QUADS); glNormal3f(0, 1, 0);
            glVertex3f(x,      0.052f, z - 0.035f);
            glVertex3f(x+0.7f, 0.052f, z - 0.035f);
            glVertex3f(x+0.7f, 0.052f, z + 0.035f);
            glVertex3f(x,      0.052f, z + 0.035f);
            glEnd();
        }
    }
    for (float z = -ROAD_LENGTH; z < ROAD_LENGTH; z += 1.4f) {
        if (fabsf(z) < INTER_HALF) continue;
        for (int side = -1; side <= 1; side += 2) {
            float x = side * 2.2f;
            glBegin(GL_QUADS); glNormal3f(0, 1, 0);
            glVertex3f(x - 0.035f, 0.052f, z);
            glVertex3f(x + 0.035f, 0.052f, z);
            glVertex3f(x + 0.035f, 0.052f, z+0.7f);
            glVertex3f(x - 0.035f, 0.052f, z+0.7f);
            glEnd();
        }
    }

    /* stop lines (white) at each entry */
    set_color(0.92f, 0.92f, 0.92f);
    /* North-bound stop (cars coming from south, stop on the south side of intersection) */
    glBegin(GL_QUADS); glNormal3f(0,1,0);
    glVertex3f( 0.1f, 0.05f, INTER_HALF + 0.2f);
    glVertex3f( ROAD_HALF_WIDTH, 0.05f, INTER_HALF + 0.2f);
    glVertex3f( ROAD_HALF_WIDTH, 0.05f, INTER_HALF + 0.5f);
    glVertex3f( 0.1f, 0.05f, INTER_HALF + 0.5f);
    glEnd();
    /* South-bound */
    glBegin(GL_QUADS); glNormal3f(0,1,0);
    glVertex3f(-ROAD_HALF_WIDTH, 0.05f, -INTER_HALF - 0.5f);
    glVertex3f(-0.1f,             0.05f, -INTER_HALF - 0.5f);
    glVertex3f(-0.1f,             0.05f, -INTER_HALF - 0.2f);
    glVertex3f(-ROAD_HALF_WIDTH, 0.05f, -INTER_HALF - 0.2f);
    glEnd();
    /* East-bound */
    glBegin(GL_QUADS); glNormal3f(0,1,0);
    glVertex3f(-INTER_HALF - 0.5f, 0.05f, 0.1f);
    glVertex3f(-INTER_HALF - 0.2f, 0.05f, 0.1f);
    glVertex3f(-INTER_HALF - 0.2f, 0.05f, ROAD_HALF_WIDTH);
    glVertex3f(-INTER_HALF - 0.5f, 0.05f, ROAD_HALF_WIDTH);
    glEnd();
    /* West-bound */
    glBegin(GL_QUADS); glNormal3f(0,1,0);
    glVertex3f( INTER_HALF + 0.2f, 0.05f, -ROAD_HALF_WIDTH);
    glVertex3f( INTER_HALF + 0.5f, 0.05f, -ROAD_HALF_WIDTH);
    glVertex3f( INTER_HALF + 0.5f, 0.05f, -0.1f);
    glVertex3f( INTER_HALF + 0.2f, 0.05f, -0.1f);
    glEnd();

    /* zebra crossings (white stripes) at each side */
    set_color(0.92f, 0.92f, 0.92f);
    /* North crossing (top side, on x axis) */
    for (float x = -ROAD_HALF_WIDTH + 0.3f; x < ROAD_HALF_WIDTH; x += 0.7f) {
        glBegin(GL_QUADS); glNormal3f(0,1,0);
        glVertex3f(x,        0.06f, -INTER_HALF - 0.8f);
        glVertex3f(x + 0.4f, 0.06f, -INTER_HALF - 0.8f);
        glVertex3f(x + 0.4f, 0.06f, -INTER_HALF - 0.1f);
        glVertex3f(x,        0.06f, -INTER_HALF - 0.1f);
        glEnd();
    }
    /* South crossing */
    for (float x = -ROAD_HALF_WIDTH + 0.3f; x < ROAD_HALF_WIDTH; x += 0.7f) {
        glBegin(GL_QUADS); glNormal3f(0,1,0);
        glVertex3f(x,        0.06f,  INTER_HALF + 0.1f);
        glVertex3f(x + 0.4f, 0.06f,  INTER_HALF + 0.1f);
        glVertex3f(x + 0.4f, 0.06f,  INTER_HALF + 0.8f);
        glVertex3f(x,        0.06f,  INTER_HALF + 0.8f);
        glEnd();
    }
    /* East crossing */
    for (float z = -ROAD_HALF_WIDTH + 0.3f; z < ROAD_HALF_WIDTH; z += 0.7f) {
        glBegin(GL_QUADS); glNormal3f(0,1,0);
        glVertex3f( INTER_HALF + 0.1f, 0.06f, z);
        glVertex3f( INTER_HALF + 0.8f, 0.06f, z);
        glVertex3f( INTER_HALF + 0.8f, 0.06f, z + 0.4f);
        glVertex3f( INTER_HALF + 0.1f, 0.06f, z + 0.4f);
        glEnd();
    }
    /* West crossing */
    for (float z = -ROAD_HALF_WIDTH + 0.3f; z < ROAD_HALF_WIDTH; z += 0.7f) {
        glBegin(GL_QUADS); glNormal3f(0,1,0);
        glVertex3f(-INTER_HALF - 0.8f, 0.06f, z);
        glVertex3f(-INTER_HALF - 0.1f, 0.06f, z);
        glVertex3f(-INTER_HALF - 0.1f, 0.06f, z + 0.4f);
        glVertex3f(-INTER_HALF - 0.8f, 0.06f, z + 0.4f);
        glEnd();
    }
}

/* Draw a single traffic-light pole with three lamps.
 *  light_color = color currently shown
 *  pos_x, pos_z = base on ground
 *  yaw = rotation so the lamp head faces the lane
 */
static void draw_traffic_light(float px, float pz, float yaw,
                               light_color_t color)
{
    glPushMatrix();
    glTranslatef(px, 0, pz);
    glRotatef(yaw, 0, 1, 0);

    /* Pole */
    set_color(0.20f, 0.20f, 0.20f);
    glPushMatrix();
        glTranslatef(0, 1.6f, 0);
        draw_box(0.18f, 3.2f, 0.18f);
    glPopMatrix();

    /* Housing (a small black box) */
    set_color(0.10f, 0.10f, 0.10f);
    glPushMatrix();
        glTranslatef(0, 3.6f, 0.35f);
        draw_box(0.55f, 1.5f, 0.45f);
    glPopMatrix();

    /* Lamps: red(top), yellow(mid), green(bottom) */
    GLfloat lamp_y[3] = { 4.15f, 3.65f, 3.15f };
    light_color_t order[3] = { LIGHT_RED, LIGHT_YELLOW, LIGHT_GREEN };
    GLfloat colors[3][3] = {
        {0.95f, 0.10f, 0.10f},
        {0.95f, 0.85f, 0.15f},
        {0.15f, 0.85f, 0.20f}
    };
    for (int i = 0; i < 3; ++i) {
        glPushMatrix();
        glTranslatef(0, lamp_y[i], 0.58f);
        if (order[i] == color) {
            set_color(colors[i][0], colors[i][1], colors[i][2]);
            set_emissive(colors[i][0] * 0.8f,
                         colors[i][1] * 0.8f,
                         colors[i][2] * 0.8f);
        } else {
            set_color(colors[i][0] * 0.25f,
                      colors[i][1] * 0.25f,
                      colors[i][2] * 0.25f);
            clear_emissive();
        }
        glutSolidSphere(0.18f, 16, 16);
        clear_emissive();
        glPopMatrix();
    }

    glPopMatrix();
}


static void draw_traffic_light_pair(float px, float pz, float yaw,
                                    light_color_t straight_color,
                                    light_color_t left_color,
                                    int horizontal_offset)
{
    /* Two separate heads per approach: one for straight/right, one for protected left. */
    float dx = horizontal_offset ? 0.75f : 0.0f;
    float dz = horizontal_offset ? 0.0f : 0.75f;

    draw_traffic_light(px - dx, pz - dz, yaw, straight_color);
    draw_traffic_light(px + dx, pz + dz, yaw, left_color);
}

/* ---------- vehicles ------------------------------------------------- */
static void draw_car(float r, float g, float b)
{
    /* body */
    set_color(r, g, b);
    glPushMatrix();
    glTranslatef(0, 0.30f, 0);
    draw_box(1.6f, 0.45f, 0.85f);
    glPopMatrix();

    /* cabin */
    set_color(r * 0.5f, g * 0.5f, b * 0.5f);
    glPushMatrix();
    glTranslatef(-0.05f, 0.65f, 0);
    draw_box(0.9f, 0.35f, 0.75f);
    glPopMatrix();

    /* wheels */
    set_color(0.05f, 0.05f, 0.05f);
    for (int sx = -1; sx <= 1; sx += 2)
    for (int sz = -1; sz <= 1; sz += 2) {
        glPushMatrix();
        glTranslatef(sx * 0.55f, 0.12f, sz * 0.42f);
        glutSolidSphere(0.16f, 10, 10);
        glPopMatrix();
    }
}

static void draw_emergency_car(int t_ms)
{
    draw_car(0.85f, 0.10f, 0.10f);
    /* roof lightbar — alternates red and blue */
    int blink = (t_ms / 250) & 1;
    glPushMatrix();
    glTranslatef(0, 1.0f, 0);
    if (blink) { set_color(1.0f, 0.1f, 0.1f); set_emissive(1.0f, 0.1f, 0.1f); }
    else       { set_color(0.1f, 0.3f, 1.0f); set_emissive(0.1f, 0.3f, 1.0f); }
    draw_box(0.45f, 0.10f, 0.55f);
    clear_emissive();
    glPopMatrix();
}


static int phase_allows_straight(direction_t d)
{
    if ((d == DIR_NORTH || d == DIR_SOUTH) && snap.current_phase == PHASE_NS_GREEN)
        return 1;
    if ((d == DIR_EAST || d == DIR_WEST) && snap.current_phase == PHASE_EW_GREEN)
        return 1;
    if (snap.current_phase == PHASE_EMERGENCY && snap.emergency_active &&
        snap.emergency_direction == d)
        return 1;
    return 0;
}

static int phase_allows_left(direction_t d)
{
    if ((d == DIR_NORTH || d == DIR_SOUTH) && snap.current_phase == PHASE_NS_LEFT)
        return 1;
    if ((d == DIR_EAST || d == DIR_WEST) && snap.current_phase == PHASE_EW_LEFT)
        return 1;
    return 0;
}

static float phase_elapsed_seconds(void)
{
    time_t now = time(NULL);
    float e = (float)(now - snap.phase_started) + fmodf(t_animation, 1.0f);
    if (e < 0.0f) e = 0.0f;
    return e;
}

/* Draw one car following a realistic lane path.
 * The GUI splits the logical queue visually into two lanes:
 *   - straight/right lane: moves only on the normal green signal.
 *   - left-turn lane: moves only on the protected left-turn signal.
 * This matches the instructor note: a left-turning car must wait for its own
 * separate green light instead of using the straight/right light. */
static void draw_car_on_route(direction_t d, int turning_left, float u,
                              float r, float g, float b)
{
    if (u < 0.0f) u = 0.0f;
    if (u > 1.0f) u = 1.0f;

    const float L = ROAD_LENGTH + 2.0f;
    const float lane_straight = 1.25f;
    const float lane_left     = 3.10f;  /* outer lane dedicated to left turns */
    float x = 0.0f, z = 0.0f, yaw = 0.0f;

    if (!turning_left) {
        switch (d) {
        case DIR_NORTH: /* travelling South -> North */
            x = lane_straight; z = L - u * (2.0f * L); yaw = 90.0f; break;
        case DIR_SOUTH: /* travelling North -> South */
            x = -lane_straight; z = -L + u * (2.0f * L); yaw = -90.0f; break;
        case DIR_EAST:  /* travelling West -> East */
            x = -L + u * (2.0f * L); z = lane_straight; yaw = 0.0f; break;
        case DIR_WEST:  /* travelling East -> West */
            x = L - u * (2.0f * L); z = -lane_straight; yaw = 180.0f; break;
        }
    } else {
        /* Piecewise protected left-turn paths. The first segment approaches
         * the stop line, the middle segment bends inside the intersection,
         * and the final segment exits along the new road. */
        float a = 0.42f, b = 0.66f;
        float v;
        if (u < a) {
            v = u / a;
            switch (d) {
            case DIR_NORTH: x = lane_left;  z = L - v * (L + 0.8f); yaw = 90.0f; break;
            case DIR_SOUTH: x = -lane_left; z = -L + v * (L + 0.8f); yaw = -90.0f; break;
            case DIR_EAST:  x = -L + v * (L + 0.8f); z = lane_left; yaw = 0.0f; break;
            case DIR_WEST:  x = L - v * (L + 0.8f);  z = -lane_left; yaw = 180.0f; break;
            }
        } else if (u < b) {
            v = (u - a) / (b - a);
            switch (d) {
            case DIR_NORTH: /* from South->North, left turn to West */
                x = lane_left + v * (-lane_straight - lane_left);
                z = -0.8f + v * (-lane_straight + 0.8f);
                yaw = 90.0f + v * 90.0f;
                break;
            case DIR_SOUTH: /* from North->South, left turn to East */
                x = -lane_left + v * (lane_straight + lane_left);
                z = 0.8f + v * (lane_straight - 0.8f);
                yaw = -90.0f + v * 90.0f;
                break;
            case DIR_EAST: /* from West->East, left turn to North */
                x = -0.8f + v * (lane_straight + 0.8f);
                z = lane_left + v * (-lane_straight - lane_left);
                yaw = 0.0f + v * 90.0f;
                break;
            case DIR_WEST: /* from East->West, left turn to South */
                x = 0.8f + v * (-lane_straight - 0.8f);
                z = -lane_left + v * (lane_straight + lane_left);
                yaw = 180.0f - v * 270.0f;
                break;
            }
        } else {
            v = (u - b) / (1.0f - b);
            switch (d) {
            case DIR_NORTH: x = -lane_straight - v * (L - lane_straight); z = -lane_straight; yaw = 180.0f; break;
            case DIR_SOUTH: x = lane_straight + v * (L - lane_straight);  z = lane_straight;  yaw = 0.0f; break;
            case DIR_EAST:  x = lane_straight; z = -lane_straight - v * (L - lane_straight); yaw = 90.0f; break;
            case DIR_WEST:  x = -lane_straight; z = lane_straight + v * (L - lane_straight);  yaw = -90.0f; break;
            }
        }
    }

    glPushMatrix();
    glTranslatef(x, 0, z);
    glRotatef(yaw, 0, 1, 0);
    draw_car(r, g, b);
    glPopMatrix();
}

static void draw_waiting_car(direction_t d, int turning_left, int idx,
                             float r, float g, float b)
{
    const float L0 = INTER_HALF + 1.7f + idx * 2.15f;
    const float lane_straight = 1.25f;
    const float lane_left     = 3.10f;
    float x = 0.0f, z = 0.0f, yaw = 0.0f;
    float lane = turning_left ? lane_left : lane_straight;

    switch (d) {
    case DIR_NORTH: x = lane;  z = L0;  yaw = 90.0f; break;
    case DIR_SOUTH: x = -lane; z = -L0; yaw = -90.0f; break;
    case DIR_EAST:  x = -L0; z = lane;  yaw = 0.0f; break;
    case DIR_WEST:  x = L0;  z = -lane; yaw = 180.0f; break;
    }

    glPushMatrix();
    glTranslatef(x, 0, z);
    glRotatef(yaw, 0, 1, 0);
    draw_car(r, g, b);
    glPopMatrix();
}

static void draw_vehicles_queue(direction_t d, int count)
{
    if (count <= 0) return;
    int shown = count > 8 ? 8 : count;
    float palette[][3] = {
        {0.2f, 0.5f, 0.9f}, {0.95f, 0.95f, 0.95f}, {0.15f, 0.55f, 0.25f},
        {0.85f, 0.6f, 0.15f}, {0.6f, 0.2f, 0.7f},  {0.3f, 0.3f, 0.35f},
        {0.8f, 0.25f, 0.25f}, {0.15f, 0.7f, 0.7f}
    };

    /* Visual split: roughly half of the waiting cars want the protected left turn. */
    int left_count = shown / 2;
    int straight_count = shown - left_count;

    int straight_go = phase_allows_straight(d);
    int left_go     = phase_allows_left(d);
    float elapsed   = phase_elapsed_seconds();
    float car_gap_s = 1.15f;
    float travel_s  = 7.0f;

    /* Straight/right lane. Cars move only when their straight/right light is green. */
    for (int i = 0; i < straight_count; ++i) {
        float *c = palette[i % 8];
        if (straight_go) {
            float u = (elapsed - i * car_gap_s) / travel_s;
            if (u >= 0.0f && u <= 1.0f)
                draw_car_on_route(d, 0, u, c[0], c[1], c[2]);
            else if (u < 0.0f)
                draw_waiting_car(d, 0, i, c[0], c[1], c[2]);
        } else {
            draw_waiting_car(d, 0, i, c[0], c[1], c[2]);
        }
    }

    /* Dedicated left-turn lane. Cars move only on NS-LEFT/EW-LEFT. */
    for (int i = 0; i < left_count; ++i) {
        float *c = palette[(straight_count + i) % 8];
        if (left_go) {
            float u = (elapsed - i * car_gap_s) / travel_s;
            if (u >= 0.0f && u <= 1.0f)
                draw_car_on_route(d, 1, u, c[0], c[1], c[2]);
            else if (u < 0.0f)
                draw_waiting_car(d, 1, i, c[0], c[1], c[2]);
        } else {
            draw_waiting_car(d, 1, i, c[0], c[1], c[2]);
        }
    }
}
static void draw_emergency_vehicle(void)
{
    if (!snap.emergency_active) return;
    direction_t d = snap.emergency_direction;

    /* travel time: 12 seconds to cross full road length */
    float total_travel = 12.0f;
    float t     = fmodf(t_animation, total_travel);
    float speed = (ROAD_LENGTH * 2.0f + INTER_HALF * 2.0f) / total_travel;
    float pos   = t * speed;   /* 0 = far entry, increases toward exit */

    /* pos relative to intersection centre:
     * starts at +ROAD_LENGTH (far side), passes through 0 (centre),
     * exits at -ROAD_LENGTH (near side) */
    float dist = ROAD_LENGTH - pos;

    /* before intersection (dist > 0): left lane
     * after intersection (dist < 0):  right lane */
    int t_ms = (int)(t_animation * 1000);

    glPushMatrix();
    switch (d) {
    case DIR_NORTH:
        /* left lane = x=-1.3 approaching, x=+1.3 after intersection */
        if (dist > 0)
            glTranslatef(-1.3f, 0, dist);
        else
            glTranslatef(1.3f, 0, dist);
        glRotatef(90, 0, 1, 0);
        break;
    case DIR_SOUTH:
        /* left lane = x=+1.3 approaching, x=-1.3 after intersection */
        if (dist > 0)
            glTranslatef(1.3f, 0, -dist);
        else
            glTranslatef(-1.3f, 0, -dist);
        glRotatef(-90, 0, 1, 0);
        break;
    case DIR_EAST:
        /* left lane = z=-1.3 approaching, z=+1.3 after intersection */
        if (dist > 0)
            glTranslatef(-dist, 0, -1.3f);
        else
            glTranslatef(-dist, 0, 1.3f);
        break;
    case DIR_WEST:
        /* left lane = z=+1.3 approaching, z=-1.3 after intersection */
        if (dist > 0)
            glTranslatef(dist, 0, 1.3f);
        else
            glTranslatef(dist, 0, -1.3f);
        glRotatef(180, 0, 1, 0);
        break;
    }
    draw_emergency_car(t_ms);
    glPopMatrix();
}
/* ---------- pedestrians --------------------------------------------- */
static void draw_pedestrian(float x, float z, float r, float g, float b)
{
    /* body */
    set_color(r, g, b);
    glPushMatrix();
    glTranslatef(x, 0.55f, z);
    draw_box(0.22f, 0.55f, 0.22f);
    glPopMatrix();
    /* head */
    set_color(0.95f, 0.82f, 0.68f);
    glPushMatrix();
    glTranslatef(x, 1.0f, z);
    glutSolidSphere(0.15f, 12, 12);
    glPopMatrix();
    /* legs */
    set_color(0.2f, 0.2f, 0.45f);
    glPushMatrix();
    glTranslatef(x - 0.07f, 0.22f, z);
    draw_box(0.10f, 0.40f, 0.10f);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(x + 0.07f, 0.22f, z);
    draw_box(0.10f, 0.40f, 0.10f);
    glPopMatrix();
}

static void draw_pedestrians(void)
{
    /* waiting pedestrians on the corner sidewalks */
    for (int i = 0; i < NUM_DIRECTIONS; ++i) {
        if (!snap.pedestrian_pending[i]) continue;
        float colors[][3] = {
            {0.85f, 0.20f, 0.20f}, {0.20f, 0.55f, 0.85f},
            {0.20f, 0.65f, 0.35f}, {0.85f, 0.45f, 0.20f}
        };
        float x = 0, z = 0;
        switch (i) {
        case DIR_NORTH: x = ROAD_HALF_WIDTH + 1.3f; z = -INTER_HALF - 0.4f; break;
        case DIR_SOUTH: x = -ROAD_HALF_WIDTH-1.3f;  z =  INTER_HALF + 0.4f; break;
        case DIR_EAST:  x = -INTER_HALF - 0.4f;     z = -ROAD_HALF_WIDTH-1.3f; break;
        case DIR_WEST:  x =  INTER_HALF + 0.4f;     z =  ROAD_HALF_WIDTH + 1.3f; break;
        }
        draw_pedestrian(x, z, colors[i][0], colors[i][1], colors[i][2]);
    }

    /* active pedestrians walking across (during pedestrian phase) */
    /* active pedestrians walking across (during pedestrian phase) */
    if (snap.pedestrian_active) {
        /* clamp walk to 0..1 so pedestrians walk once and stop */
        float total = (float)snap.pedestrian_remaining;
        float elapsed = (float)(snap.t_pedestrian - snap.pedestrian_remaining);
        float walk = (snap.t_pedestrian > 0)
                     ? (elapsed / ((float)snap.t_pedestrian * 0.6f))
                     : 0.0f;
        if (walk > 1.0f) walk = 1.0f;

        /* north-south crossings */
        draw_pedestrian(-ROAD_HALF_WIDTH + walk * (ROAD_HALF_WIDTH * 2.0f),
                        -INTER_HALF - 0.45f, 0.2f, 0.5f, 0.9f);
        draw_pedestrian( ROAD_HALF_WIDTH - walk * (ROAD_HALF_WIDTH * 2.0f),
                         INTER_HALF + 0.45f, 0.9f, 0.3f, 0.3f);
        draw_pedestrian(-INTER_HALF - 0.45f,
                        -ROAD_HALF_WIDTH + walk * (ROAD_HALF_WIDTH * 2.0f),
                        0.3f, 0.7f, 0.3f);
        draw_pedestrian( INTER_HALF + 0.45f,
                         ROAD_HALF_WIDTH - walk * (ROAD_HALF_WIDTH * 2.0f),
                        0.9f, 0.6f, 0.2f);
        (void)total;
    }
}

static void add_recent_event(const char *msg)
{
    strncpy(recent_events[recent_head], msg, 127);
    recent_events[recent_head][127] = '\0';
    recent_head = (recent_head + 1) % MAX_RECENT_EVENTS;
    if (recent_count < MAX_RECENT_EVENTS) recent_count++;
}

static void poll_recent_events(void)
{
    /* GUI is passive; recent-events are inferred from phase/emergency changes. */

    /* detect phase changes */
    static phase_t last_phase = PHASE_STARTUP;
    if (snap.current_phase != last_phase) {
        char buf[128];
        snprintf(buf, sizeof(buf), "Phase: %s", PHASE_NAMES[snap.current_phase]);
        add_recent_event(buf);
        last_phase = snap.current_phase;
    }

    /* detect emergency */
    static int last_emerg = 0;
    if (snap.emergency_active && !last_emerg) {
        char buf[128];
        snprintf(buf, sizeof(buf), "EMERGENCY from %s",
                 DIR_NAMES[snap.emergency_direction]);
        add_recent_event(buf);
    }
    last_emerg = snap.emergency_active;

    /* detect pedestrian phase */
    static int last_ped = 0;
    if (snap.pedestrian_active && !last_ped)
        add_recent_event("Pedestrian crossing OPEN");
    if (!snap.pedestrian_active && last_ped)
        add_recent_event("Pedestrian crossing CLOSED");
    last_ped = snap.pedestrian_active;
}

/* ---------- HUD ------------------------------------------------------ */
static void draw_hud(void)
{
    /* switch to orthographic 2-D                                        */
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity();
    gluOrtho2D(0, WIN_W, 0, WIN_H);
    glMatrixMode(GL_MODELVIEW); glPushMatrix(); glLoadIdentity();

    /* translucent black panel top-left */
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(0, 0, 0, 0.55f);
    glBegin(GL_QUADS);
        glVertex2f(10,            WIN_H - 10);
        glVertex2f(360,           WIN_H - 10);
        glVertex2f(360,           WIN_H - 220);
        glVertex2f(10,            WIN_H - 220);
    glEnd();
    glDisable(GL_BLEND);

    char buf[256];
    glColor3f(0.95f, 0.95f, 0.95f);
    snprintf(buf, sizeof(buf), "Phase: %s",
             PHASE_NAMES[snap.current_phase]);
    draw_text_big(20, WIN_H - 30, buf);

    snprintf(buf, sizeof(buf), "Countdown: %d s", snap.phase_remaining);
    draw_text(20, WIN_H - 55, buf);

    snprintf(buf, sizeof(buf), "Straight/Right: N=%s S=%s E=%s W=%s",
             COLOR_NAMES[snap.light[0]], COLOR_NAMES[snap.light[1]],
             COLOR_NAMES[snap.light[2]], COLOR_NAMES[snap.light[3]]);
    draw_text(20, WIN_H - 80, buf);

    snprintf(buf, sizeof(buf), "Left-turn    : N=%s S=%s E=%s W=%s",
             COLOR_NAMES[snap.left_light[0]], COLOR_NAMES[snap.left_light[1]],
             COLOR_NAMES[snap.left_light[2]], COLOR_NAMES[snap.left_light[3]]);
    draw_text(20, WIN_H - 140, buf);

    snprintf(buf, sizeof(buf), "Queues : N=%d  S=%d  E=%d  W=%d",
             snap.waiting_vehicles[0], snap.waiting_vehicles[1],
             snap.waiting_vehicles[2], snap.waiting_vehicles[3]);
    draw_text(20, WIN_H - 100, buf);

    snprintf(buf, sizeof(buf), "Pedestrians pending: N=%d S=%d E=%d W=%d",
             snap.pedestrian_pending[0], snap.pedestrian_pending[1],
             snap.pedestrian_pending[2], snap.pedestrian_pending[3]);
    draw_text(20, WIN_H - 120, buf);

    if (snap.emergency_active) {
        glColor3f(1, 0.3f, 0.3f);
        snprintf(buf, sizeof(buf), "*** EMERGENCY from %s ***",
                 DIR_NAMES[snap.emergency_direction]);
        draw_text_big(20, WIN_H - 165, buf);
        glColor3f(0.95f, 0.95f, 0.95f);
    }

    snprintf(buf, sizeof(buf),
             "Served: %d veh   %d ped   |   Emergencies: %d   Faults: %d",
             snap.total_vehicles_served, snap.total_pedestrians_served,
             snap.total_emergencies, snap.safety_violations);
    draw_text(20, WIN_H - 190, buf);

    if (show_help) {
        /* bottom-right help panel */
        glColor4f(0, 0, 0, 0.55f);
        glEnable(GL_BLEND);
        glBegin(GL_QUADS);
            glVertex2f(WIN_W - 320, 10);
            glVertex2f(WIN_W - 10,  10);
            glVertex2f(WIN_W - 10,  170);
            glVertex2f(WIN_W - 320, 170);
        glEnd();
        glDisable(GL_BLEND);
        glColor3f(1, 1, 1);
        draw_text(WIN_W - 310, 150, "Keyboard controls:");
        draw_text(WIN_W - 310, 130, "  n / s / e / w : add a vehicle");
        draw_text(WIN_W - 310, 110, "  N / S / E / W : pedestrian button");
        draw_text(WIN_W - 310,  90, "  1 / 2 / 3 / 4 : emergency from N/S/E/W");
        draw_text(WIN_W - 310,  70, "  arrows : rotate camera");
        draw_text(WIN_W - 310,  50, "  +  /  - : zoom");
        draw_text(WIN_W - 310,  30, "  h : toggle help     q : quit");
    }
    /* recent events panel — bottom left */
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(0, 0, 0, 0.50f);
    glBegin(GL_QUADS);
        glVertex2f(10,   10);
        glVertex2f(360,  10);
        glVertex2f(360,  10 + MAX_RECENT_EVENTS * 18 + 10);
        glVertex2f(10,   10 + MAX_RECENT_EVENTS * 18 + 10);
    glEnd();
    glDisable(GL_BLEND);

    glColor3f(0.75f, 0.85f, 1.0f);
    draw_text(20, 10 + MAX_RECENT_EVENTS * 18, "Recent events:");
    for (int i = 0; i < recent_count; i++) {
        int idx = (recent_head - recent_count + i + MAX_RECENT_EVENTS)
                  % MAX_RECENT_EVENTS;
        glColor3f(0.90f, 0.90f, 0.90f);
        draw_text(20, 10 + (MAX_RECENT_EVENTS - 1 - i) * 18, recent_events[idx]);
    } 

    glMatrixMode(GL_PROJECTION); glPopMatrix();
    glMatrixMode(GL_MODELVIEW);  glPopMatrix();
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
}

/* ---------- snapshot ------------------------------------------------- */
static void take_snapshot(void)
{
    if (!S) return;
    if (sem_lock(semid) == 0) {
        snap = *S;
        sem_unlock(semid);
    }
}

/* ---------- display callback ---------------------------------------- */
static void on_display(void)
{
    take_snapshot();
    poll_recent_events();
    t_animation += 0.05f;

    glClearColor(0.55f, 0.75f, 0.9f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    /* camera */
    float cx = cam_dist * sinf(cam_rotate * M_PI / 180.0f) *
               cosf(cam_angle  * M_PI / 180.0f);
    float cz = cam_dist * cosf(cam_rotate * M_PI / 180.0f) *
               cosf(cam_angle  * M_PI / 180.0f);
    float cy = cam_dist * sinf(cam_angle  * M_PI / 180.0f);
    gluLookAt(cx, cy, cz,  0, 0, 0,  0, 1, 0);

    draw_ground();
    draw_roads();

    /* traffic lights at each corner; each approach has two heads:
       straight/right and protected left-turn. */
    draw_traffic_light_pair( INTER_HALF + 1.5f,  INTER_HALF + 1.5f,
                             180.0f, snap.light[DIR_NORTH], snap.left_light[DIR_NORTH], 1);
    draw_traffic_light_pair(-INTER_HALF - 1.5f, -INTER_HALF - 1.5f,
                               0.0f, snap.light[DIR_SOUTH], snap.left_light[DIR_SOUTH], 1);
    draw_traffic_light_pair(-INTER_HALF - 1.5f,  INTER_HALF + 1.5f,
                             -90.0f, snap.light[DIR_EAST], snap.left_light[DIR_EAST], 0);
    draw_traffic_light_pair( INTER_HALF + 1.5f, -INTER_HALF - 1.5f,
                              90.0f, snap.light[DIR_WEST], snap.left_light[DIR_WEST], 0);

    /* queued vehicles */
    for (int i = 0; i < NUM_DIRECTIONS; ++i)
        draw_vehicles_queue((direction_t)i, snap.waiting_vehicles[i]);

    draw_emergency_vehicle();
    draw_pedestrians();

    draw_hud();

    glutSwapBuffers();
}

static void on_reshape(int w, int h)
{
    WIN_W = w; WIN_H = h;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION); glLoadIdentity();
    gluPerspective(45.0, (double)w / (h > 0 ? h : 1), 0.5, 200.0);
    glMatrixMode(GL_MODELVIEW);
}

/* ---------- input ---------------------------------------------------- */
static void inject_event(long mtype, direction_t d)
{
    evt_msg_t e;
    memset(&e, 0, sizeof(e));
    e.mtype     = mtype;
    e.direction = d;
    e.count     = 1;
    e.timestamp = time(NULL);
    snprintf(e.info, sizeof(e.info), "from-gui");
    msgsnd(qevt, &e, sizeof(e) - sizeof(long), IPC_NOWAIT);
    send_log(qlog, "GUI", 0, "Injected %s event for %s",
             (mtype == MTYPE_EVT_VEHICLE)    ? "vehicle"    :
             (mtype == MTYPE_EVT_PEDESTRIAN) ? "pedestrian" :
             (mtype == MTYPE_EVT_EMERGENCY)  ? "emergency"  : "?",
             DIR_NAMES[d]);
}

static void on_key(unsigned char k, int x, int y)
{
    (void)x; (void)y;
    switch (k) {
    case 'n': inject_event(MTYPE_EVT_VEHICLE, DIR_NORTH); break;
    case 's': inject_event(MTYPE_EVT_VEHICLE, DIR_SOUTH); break;
    case 'e': inject_event(MTYPE_EVT_VEHICLE, DIR_EAST);  break;
    case 'w': inject_event(MTYPE_EVT_VEHICLE, DIR_WEST);  break;
    case 'N': inject_event(MTYPE_EVT_PEDESTRIAN, DIR_NORTH); break;
    case 'S': inject_event(MTYPE_EVT_PEDESTRIAN, DIR_SOUTH); break;
    case 'E': inject_event(MTYPE_EVT_PEDESTRIAN, DIR_EAST);  break;
    case 'W': inject_event(MTYPE_EVT_PEDESTRIAN, DIR_WEST);  break;
    case '1': inject_event(MTYPE_EVT_EMERGENCY, DIR_NORTH); break;
    case '2': inject_event(MTYPE_EVT_EMERGENCY, DIR_SOUTH); break;
    case '3': inject_event(MTYPE_EVT_EMERGENCY, DIR_EAST);  break;
    case '4': inject_event(MTYPE_EVT_EMERGENCY, DIR_WEST);  break;
    case '+': case '=': cam_dist -= 1.5f; if (cam_dist < 8) cam_dist = 8; break;
    case '-': case '_': cam_dist += 1.5f; if (cam_dist > 60) cam_dist = 60; break;
    case 'h': case 'H': show_help = !show_help; break;
    case 'q': case 'Q': case 27:
        if (S) { sem_lock(semid); S->running = 0; sem_unlock(semid); }
        exit(0);
    }
}

static void on_special(int k, int x, int y)
{
    (void)x; (void)y;
    switch (k) {
    case GLUT_KEY_LEFT:  cam_rotate -= 4.0f; break;
    case GLUT_KEY_RIGHT: cam_rotate += 4.0f; break;
    case GLUT_KEY_UP:    cam_angle  += 2.0f; if (cam_angle >  80) cam_angle =  80; break;
    case GLUT_KEY_DOWN:  cam_angle  -= 2.0f; if (cam_angle <  10) cam_angle =  10; break;
    }
}

/* ---------- timer (animation) --------------------------------------- */
static void on_timer(int v)
{
    (void)v;
    glutPostRedisplay();
    glutTimerFunc(60, on_timer, 0);   /* ~16 fps is plenty */
}

/* ---------- lighting ------------------------------------------------- */
static void init_gl(void)
{
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);

    GLfloat lpos[]  = { 10.0f, 20.0f, 10.0f, 0.0f };
    GLfloat lamb[]  = { 0.3f, 0.3f, 0.35f, 1.0f };
    GLfloat ldiff[] = { 0.9f, 0.9f, 0.85f, 1.0f };
    GLfloat lspec[] = { 0.5f, 0.5f, 0.5f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, lpos);
    glLightfv(GL_LIGHT0, GL_AMBIENT,  lamb);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  ldiff);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lspec);

    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    glShadeModel(GL_SMOOTH);
    glClearDepth(1.0);
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("ENCS4330 — Real-Time Traffic Light Control System");

    /* attach IPC */
    shmid = ipc_shm_attach_existing();
    semid = ipc_sem_attach_existing();
    qevt  = ipc_q_attach_existing(IPC_ID_MQ_EVT);
    qlog  = ipc_q_attach_existing(IPC_ID_MQ_LOG);
    if (shmid < 0 || semid < 0 || qevt < 0 || qlog < 0) {
        fprintf(stderr, "gui: IPC attach failed — start main first\n");
        return 1;
    }
    S = (shared_state_t *)shmat(shmid, NULL, 0);
    if (S == (void *)-1) { perror("shmat"); return 1; }
    send_log(qlog, "GUI", 0, "OpenGL GUI attached");

    init_gl();
    glutDisplayFunc(on_display);
    glutReshapeFunc(on_reshape);
    glutKeyboardFunc(on_key);
    glutSpecialFunc(on_special);
    glutTimerFunc(60, on_timer, 0);
    glutMainLoop();
    return 0;
}
